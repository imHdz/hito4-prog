import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ComboListener implements ActionListener {
    private Hito4 hito4;
    public ComboListener(Hito4 hito4) {
        this.hito4=hito4;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JComboBox<String>comboBox= hito4.getComboBox();
        String actualimage= (String) comboBox.getSelectedItem();
        hito4.loadImage(actualimage);
    }
}
