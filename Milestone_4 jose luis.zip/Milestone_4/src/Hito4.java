import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Hito4 extends JFrame implements ActionListener {
    JTextField text ;
    JButton button ;
    JCheckBox checkbox;
    private JComboBox <String> comboBox= new JComboBox();
    private JLabel image;
    public Hito4() {
        final String PASSWORD = "damocles";
        checkbox = new JCheckBox("Save your comment");
        button = new JButton("SAVE");
        String enteredPassword = JOptionPane.showInputDialog(null, "PASSWORD:");
        if (enteredPassword!=null && enteredPassword.equals(PASSWORD)){
            this.setTitle("Swing-Example 2");
            setVisible(true);
            this.setPreferredSize(new Dimension(500, 500));
            this.pack();
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
            loadCombo();
            String actualimage=(String)comboBox.getSelectedItem();
            image = new JLabel();
            text= new JTextField(20);
            loadImage(actualimage);
            JPanel buttonPanel = new JPanel();
            JPanel mainPanel= new JPanel();
            mainPanel.setLayout(new BorderLayout());
            JPanel leftPanel=new JPanel();
            JPanel rigthPanel= new JPanel();
            JPanel rigthContent=new JPanel();
            rigthContent.setLayout(new GridLayout(2,1,0,0));
            rigthContent.add(text);
            rigthPanel.add(rigthContent);
            rigthPanel.setBorder(new EmptyBorder(250,0,0,0));
            leftPanel.setLayout(new GridLayout(3,1,0,0));
            JPanel comboBoxPanel= new JPanel();
            comboBoxPanel.setLayout(new FlowLayout());
            buttonPanel.add(button);
            comboBox.setPreferredSize(new Dimension(250,60));
            comboBoxPanel.add(comboBox);
            leftPanel.add(comboBoxPanel);
            leftPanel.add(image);
            leftPanel.add(checkbox);
            mainPanel.add(leftPanel,BorderLayout.WEST);
            mainPanel.add(rigthPanel,BorderLayout.EAST);
            mainPanel.add(buttonPanel,BorderLayout.SOUTH);
            this.add(mainPanel);
            checkbox.setSelected(true);
            comboBox.addActionListener(new ComboListener(this));
            button.addActionListener(this);

        }else{
            System.exit(0);
        }
    }
    private void loadCombo() {
        String[] fileNames = new File("img/").list();
        for (String s :fileNames){
            comboBox.addItem(s);
        }
    }
    public void loadImage(String actualimage){
        ImageIcon icon = new ImageIcon("img/"+actualimage);
        image.setIcon(icon);
    }


    public JComboBox<String> getComboBox() {
        return comboBox;
    }
    @Override
    public void actionPerformed(ActionEvent e) {

        JButton boton = (JButton)e.getSource();
        if(boton==button){System.out.println("");
            guardarComent();
        }

    }
    public void guardarComent(){
       String actualImage = (String) comboBox.getSelectedItem();

        String comment = text.getText();

        if(checkbox.isSelected() && !comment.isEmpty()){
            try {
                String file = "comments/"+actualImage.replace(".jpg",".txt") ;
                System.out.println(actualImage);
                System.out.println(file);
                FileWriter writer = new FileWriter(file,true);
                writer.write(comment + "\n");
                writer.close();
            }
            catch (IOException ex){
                ex.getMessage();
            }
        }
    }
    public static void main(String[] args) {
        Hito4 hito4 = new Hito4();
        hito4.setVisible(true);
    }
}
